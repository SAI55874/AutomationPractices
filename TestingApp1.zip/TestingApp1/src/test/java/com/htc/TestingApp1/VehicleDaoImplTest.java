package com.htc.TestingApp1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

class VehicleDaoImplTest {
	
	VehicleDao vhs= new VehicleDaoImpl();
	@Nested
	@DisplayName("TestsForAddMethod")
	class TestAddVehicle{
		@Test
		void test1() {
			assertTrue(vhs.addVehicle(null));
		}

		@Test
		void test2() {
			assertTrue(vhs.addVehicle(new Vehicle("AP_39_PD_2121","Audi","white","Car",4000,1000000)));
		}
		
		@Test
		void test3() {
			assertTrue(vhs.addVehicle(new Vehicle("","","white","Car",4000,1000000)));
		}
		
		@Test
		void test4() {
			assertTrue(vhs.addVehicle(new Vehicle()));
		}
	}
	
	@Nested
	@DisplayName("TestsForRemoveMethod")
	class TestRemovehicle{
		
		@Test
		void test1_1() {
			assertFalse(vhs.removeVehicle(null));
		}
		
		@Test
		void test1_2() {
			assertTrue(vhs.removeVehicle("AP_39_PD_2121"));
		}
		
		@Test
		void test1_5() {
			assertFalse(vhs.removeVehicle("AP_23_TT_3232"));
		}
		
		@Test
		void test1_3() {
			assertFalse(vhs.removeVehicle("HD"));
		}
		
		@Test
		void test1_4() {
			assertFalse(vhs.removeVehicle(""));
		}
	}
	

}
