package com.htc.pojo;

import java.util.Objects;

public class HTCtraing {
private String CadidateId;
private String CandidateName;
private String EmailId;
private String Location;
public String getCadidateId() {
	return CadidateId;
}
public void setCadidateId(String cadidateId) {
	CadidateId = cadidateId;
}
public String getCandidateName() {
	return CandidateName;
}
public void setCandidateName(String candidateName) {
	CandidateName = candidateName;
}
public String getEmailId() {
	return EmailId;
}
public void setEmailId(String emailId) {
	EmailId = emailId;
}
public String getLocation() {
	return Location;
}
public void setLocation(String location) {
	Location = location;
}
public HTCtraing() {
	super();
	// TODO Auto-generated constructor stub
}
public HTCtraing(String cadidateId, String candidateName, String emailId, String location) {
	super();
	CadidateId = cadidateId;
	CandidateName = candidateName;
	EmailId = emailId;
	Location = location;
}


@Override
public int hashCode() {
	return Objects.hash(CadidateId);
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	HTCtraing other = (HTCtraing) obj;
	return Objects.equals(CadidateId, other.CadidateId);
}
@Override
public String toString() {
	return "HTCtraing [CadidateId=" + CadidateId + ", CandidateName=" + CandidateName + ", EmailId=" + EmailId
			+ ", Location=" + Location + "]";
}

}
