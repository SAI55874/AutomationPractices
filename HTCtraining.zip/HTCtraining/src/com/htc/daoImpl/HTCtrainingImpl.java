package com.htc.daoImpl;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.htc.dao.HTCtrainingDao;
import com.htc.pojo.HTCtraing;



public class HTCtrainingImpl implements HTCtrainingDao{

	
	List<HTCtraing>  Training=new ArrayList<>();
	public HTCtrainingImpl() {
		
	}

	@Override
	public boolean addCandidate(HTCtraing htc) {
		boolean flag=false;
		 Training.add(htc);
		flag=true;
		return flag;
	}

	@Override
	public boolean removeCandidate(String CandidateId) {
		
boolean flag = false;

		
HTCtraing veh = null;
		for (HTCtraing htc : Training) {
			if(CandidateId.equals(htc.getCadidateId())) {
				Training.remove(htc);
				
				break;
			}
		}
		flag=true;
		return flag;
	}

	

	@Override
	public HTCtraing modifyCandidate(String CandidateId, String CandidateName, String Email) {
		for (HTCtraing htc : Training) {
			if(CandidateId.equals(htc.getCadidateId())) {
				htc.setCandidateName(CandidateName);
				htc.setEmailId(Email);
				
				break;
			}
		}
		
		
		return null;
	}

	@Override
	public List<HTCtraing> getAllCandidate() {
		return Training;
		
	}

	@Override
	public Optional<HTCtraing> getCandidate(String CandidateId) {
		HTCtraing veh = null;
		for (HTCtraing htc : Training) {
			if(CandidateId.equals(htc.getCadidateId())) {
				veh=htc;
				break;
			}
		}
		
		return Optional.ofNullable(veh);
	}
	
	public void ExcelToDb() throws IOException{
		List<HTCtraing> trs= new ArrayList<>();
FileInputStream fileInput = new FileInputStream("HTCtraing.xlsx");


		
		Workbook workbook = new XSSFWorkbook(fileInput);
		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Sheet> sheets = workbook.sheetIterator();
		
			Sheet sh =sheets.next();
//			System.out.println("Sheet name is"+sh.getSheetName());
			Iterator<Row> iterator = sh.iterator();
			iterator.next();
			while(iterator.hasNext()) {
				HTCtraing v = new HTCtraing(); 
				Row row = iterator.next();
				Iterator<Cell> cellIterator = row.iterator();
				
				while(cellIterator.hasNext()) {
					
					Cell cell = cellIterator.next();
					int columnIndex=cell.getColumnIndex();
					String cellValue = dataFormatter.formatCellValue(cell);
					String value= null;
					int valueNum = 0 ;

					
					switch (columnIndex) {
	                case 0:
	                	
	                	value=cell.getStringCellValue();
	                	
	                    v.setCadidateId(value);
	                   
	                    break;
	                case 1:
	                	value=cell.getStringCellValue();
	                   v.setCandidateName(value);;
	                   
	                    break;
	                case 2:
	                	value=cell.getStringCellValue();
	                	
	                 
	                  v.setEmailId(value);;
	                 
	                    break;
	                case 3:
	                	value=cell.getStringCellValue();
	            
	                    v.setLocation(value);
	                    
	                      break;
	                
	               
					
				}
				
			}Training.add(v);
			
		}
			
		
		workbook.close();
		
		trs=Training;
		connection=DbUtil.getConnection();
			
		    try {
		       
//		        Class.forName("com.mysql.cj.jdbc.Driver");
//		        connection = DriverManager.getConnection(
//		            "jdbc:mysql://localhost:3306/htc",
//		            "root", "root");

		        Statement statement = null;
		        
		        
		        
		        statement = connection.createStatement();
		        for (HTCtraing trn : trs) {
		        	String sql= "INSERT INTO vehicles VALUES ("+"'"+trn.getCadidateId()+"'"+","+"'"+trn.getCandidateName()+"'"+","+"'"+trn.getEmailId()+"'"+","+"'"+trn.getLocation()+"'"+")";
//		        	System.out.println(sql);
		        	statement.executeUpdate(sql);
		        	
				}
//		  statement.executeUpdate("TRUNCATE vehicles");
		        ResultSet resultSet;
		        resultSet = statement.executeQuery(
		            "select * from vehicles");
		        
		        while(resultSet.next())  
//		        	System.out.println(resultSet.getString(1)+"\t"+resultSet.getString(2)+"\t"+resultSet.getString(3));  
		        resultSet.close();
		        statement.close();
		        connection.close();
		    }
		    catch (Exception exception) {
		        
		    }
		
		
	}

}
