package com.htc.dao;

import java.util.List;
import java.util.Optional;

import com.htc.pojo.HTCtraing;



public interface HTCtrainingDao {
	boolean addCandidate(HTCtraing htc ) ;
	boolean removeCandidate(String CandidateId); 
	HTCtraing modifyCandidate(String CandidateId,String CandidateName,String Email) ;
	List<HTCtraing> getAllCandidate();
	Optional<HTCtraing> getCandidate(String CandidateId);
}
