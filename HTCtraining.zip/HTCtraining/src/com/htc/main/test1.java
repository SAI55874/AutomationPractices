package com.htc.main;

import java.io.IOException;

import com.htc.dao.HTCtrainingDao;
import com.htc.daoImpl.HTCtrainingImpl;

public class test1 {
	public static void main(String[] args) throws IOException {
		HTCtrainingDao ht=new HTCtrainingImpl();
		ht.addCandidate(null);
		ht.getAllCandidate();
		
		
		HTCtrainingImpl htcs=new HTCtrainingImpl();
		htcs.ExcelToDb();
	}

}
