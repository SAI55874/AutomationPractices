package com.htc.Junit5Basic;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.shadow.com.univocity.parsers.annotations.Nested;

import com.htc.Junit5Basic.Calculator;
@DisplayName("TestCalculator")
class CalculatorTest {

	Calculator cal;
	
	
	@BeforeEach
	void object() {
		cal=new Calculator();
	}
	@BeforeAll
    static void beforeAll() {
        
	}
 
    @AfterEach
    void afterEach() {
        
    }
 
    @AfterAll
    static void afterAll() {
        
    }

    @org.junit.jupiter.api.Nested
	@DisplayName("Tests for add method")
	class TestAddmethod {

    	Calculator cal;
    	
    	
    	@BeforeEach
    	void object() {
    		cal=new Calculator();
    	 }
  
         @AfterEach
         void afterEach() {
             
         }
         @Test
         @DisplayName("Test to add two positive numbers")
		 void addPositiveNumbers() {
			assertEquals(12,cal.Add(5, 7));
		 }
         @Test
         @DisplayName("Test to add two Negative numbers")
		 void addNegativeNumbers() {
			assertEquals(-10,cal.Add(-3, -7));
		 }
         @Test
         @DisplayName("Test to add a neg and pos number")
		 void addNegAndPosNumbers() {
			assertEquals(4,cal.Add(-3, 7));
		 }
         
         @Test
         @DisplayName("Test on adding two Zeros")
		 void addTwoZeros() {
			assertEquals(0,cal.Add(0, 0));
		 }
		
         @Test
         @DisplayName("Test to add number with Zero")
		 void addAnumWithZero() {
			assertEquals(5,cal.Add(0, 5));
		 }
	}
    
  @org.junit.jupiter.api.Nested
  @DisplayName("Test For Divide Method")
  class TestForDivideMethod{
	  Calculator cal;
  	
  	
  		@BeforeEach
  		void object() {
  		cal=new Calculator();
  		}

       @AfterEach
       void afterEach() {
           
       }
       
       @Test
       @DisplayName("Divide two positive nums")
       void divideTwoPositiveNums() {
    	   assertEquals(5, cal.Divide(15, 3));
       }
       
       @Test
       @DisplayName("Divide two negative nums")
       void divideTwoNegativeNums() {
    	   assertEquals(5, cal.Divide(-15, -3));
       }
       @org.junit.jupiter.api.Nested
       @DisplayName("Test for Exceptions")
       class testDivideExceptions {
    	   
    	   @Test
    	   void checkException() {
    		   assertThrows(ArithmeticException.class, ()-> {double i=15/0;});
    	   }
    	   
    	   @Test
    	   void checkException2() {
    		   assertThrows(ArithmeticException.class, ()-> {cal.Divide(36, 0);});
    		  
    	   }
    	   @org.junit.jupiter.api.Nested
    	  
    	   class divideMethod {
    		   @Test
    		   @DisplayName("Divide to same numbers")
    		   void testTwoNums() {
    		   assertEquals(1,cal.Divide(13,13));
    		   }
    	   }
    

       
  }
 
   
 
   
 
  } 
	
}
