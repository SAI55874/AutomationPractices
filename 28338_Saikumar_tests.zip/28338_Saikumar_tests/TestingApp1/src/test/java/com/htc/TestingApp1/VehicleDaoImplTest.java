package com.htc.TestingApp1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

class VehicleDaoImplTest {
	
	VehicleDao vhs= new VehicleDaoImpl();
	@Nested
	@DisplayName("TestsForAddMethod")
	class TestAddVehicle{
		@Test
		void test1() {
			assertTrue(vhs.addVehicle(null));
		}

		@Test
		void test2() {
			assertTrue(vhs.addVehicle(new Vehicle("AP_39_PD_2121","Audi","white","Car",4000,1000000)));
		}
		
		@Test
		void test3() {
			assertTrue(vhs.addVehicle(new Vehicle("","","white","Car",4000,1000000)));
		}
		
		@Test
		void test4() {
			assertTrue(vhs.addVehicle(new Vehicle()));
		}
	}
	
	@Nested
	@DisplayName("TestsForRemoveMethod")
	class TestRemovehicle{
		
		@Test
		void test1_0() {
			assertThrows(NullPointerException.class,()->vhs.removeVehicle(null));
		}
		
		@Test
		void test1_1() {
			assertFalse(vhs.removeVehicle(""));
		}
		
		@Test
		@DisplayName("With Valid Vehicle no")
		void test1_2() {
			assertTrue(vhs.removeVehicle("AP_39_PD_2121"));
		}
		
		@Test
		@DisplayName("With VehicleNo not in")
		void test1_5() {
			assertFalse(vhs.removeVehicle("AP_23_TT_3232"));
		}
		
		@Test
		@DisplayName("With InValid Vehicle no")
		void test1_3() {
			assertFalse(vhs.removeVehicle("HD"));
		}
		
		@Test
		void test1_4() {
			assertFalse(vhs.removeVehicle(""));
		}
		
		
		
	}
	@Nested
	@DisplayName("TestsForUpdateMethod")
	class TestUpdateVehicle{
		@Test
		void test2_1() {
			assertNull(vhs.modifyVehicle("","","",0));
		}
		
		@Test
		void test2_2() {
			assertNotNull(vhs.modifyVehicle("Ape","auto","AP_39_PD_2121",200000));
		}
		
		@Test
		void test2_3() {
			assertNull(vhs.modifyVehicle("Ape","auto","AP_39_SD_2121",200000));
		}
		
		@Test
		void test2_4() {
			assertNotNull(vhs.modifyVehicle("","","AP_39_PD_2121",0));
		}
		
	}
	@Nested
	@DisplayName("TestsForGetVehicleMethod")
	class TestGetVehicle{
		@Test
		void test3_1() {
			assertThrows(NullPointerException.class,()->vhs.getVehicle(null));
		}
		
		@Test
		void test3_2() {
			assertNotNull(vhs.getVehicle("AP_39_PD_2121"));
		}
		
		@Test
		void test3_3() {
			assertNull(vhs.getVehicle("AP_39_YY_2121"));
		}
		
		
	}
	

}
