package com.htc.TestingApp1;

import java.util.List;
import java.util.Optional;

public interface VehicleDao {
boolean addVehicle(Vehicle vehicle) ;
boolean removeVehicle(String vehicleNo) ;
Vehicle modifyVehicle(String brandName,String VehicleType,String VehicleNo,int price) ;
List<Vehicle> getAllVehicles();
Optional<Vehicle> getVehicle(String vehicleNo) ;
}
