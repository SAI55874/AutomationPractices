package com.htc.TestingApp1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Logger;



public class VehicleDaoImpl implements VehicleDao{

	
	
	List <Vehicle> vehicles=new ArrayList<>();
	
	public VehicleDaoImpl()  {
			
		Vehicle vehicle1=new Vehicle("AP_39_PD_2121","Audi","white","Car",4000,1000000);
		Vehicle vehicle2=new Vehicle("AP_39_PD_2123","benz","black","Car",4000,1000000);
		vehicles.add(vehicle1);
		vehicles.add(vehicle2);
		vehicles.add(new Vehicle("AP_39_PD_2121","Audi","white","Car",3000,20000000));
		vehicles.add(new Vehicle("TN_39_PD_2123","Benz","black","Car",3500,1000000));
		vehicles.add(new Vehicle("AP_39_PD_3345","MaruthisuZuki","black","Car",3200,500000));
		vehicles.add(new Vehicle("MP_39_PD_6464","Tataindica","black","Car",2400,600000));
		vehicles.add(new Vehicle("AP_39_PD_9999","Hundai","black","Car",4000,700000));
		vehicles.add(new Vehicle("UP_39_PD_3363","Kia","black","Car",4000,1000000));
//		vehicles.add(new Vehicle("AP_39_PD_9812","Ashokleyland","black","Lorry",4000,1000000));
//		vehicles.add(new Vehicle("AP_39_PD_6363","Kia","black","Car",2500,1000000));
//		vehicles.add(new Vehicle("TS_39_PD_8945","Isuzu","black","Car",2000,1000000));
//		vehicles.add(new Vehicle("AP_39_PD_7281","benz","black","Car",2000,1000000));
//		vehicles.add(new Vehicle("AP_39_PD_7382","RossRoyels","black","Car",6000,1000000));
//		vehicles.add(new Vehicle("AP_39_PD_9738","Ferrari","black","Car",8000,1000000));
//		vehicles.add(new Vehicle("AP_39_PD_9373","Benz","black","Lorry",8000,1000000));
//		vehicles.add(new Vehicle("AP_39_PD_9272","Benz","black","Car",4000,1000000));
//		vehicles.add(new Vehicle("AP_39_PD_9929","Mahindra","black","Lorry",4000,1000000));
//		vehicles.add(new Vehicle("AP_39_PD_8383","Fz","black","Bike",4000,1000000));
//		vehicles.add(new Vehicle("AP_39_PD_7783","Pulser","black","Bike",4000,1000000));
//		vehicles.add(new Vehicle("AP_39_PD_2122","Benz","black","Car",4000,1000000));
//		vehicles.add(new Vehicle("AP_39_PD_2132","Hero","black","Bike",4000,1000000));
//		vehicles.add(new Vehicle("AP_39_PD_7878","Tata","black","Car",4000,1000000));
//		vehicles.add(new Vehicle("AP_39_PD_5353","Asholeyland","black","Lorry",4000,1000000));
//		vehicles.add(new Vehicle("AP_39_PD_8282","JCB","black","Drozer",4000,1000000));
	}
	
	
	@Override
	public boolean addVehicle(Vehicle vehicle) {
		boolean flag=false;
		vehicles.add(vehicle);
		flag=true;
		return flag;
		
		
		
		
	}

	@Override
	public boolean removeVehicle(String vehicleNo){
		
		boolean flag = false;

		
		Vehicle veh = null;
		for (Vehicle vehicle : vehicles) {
			if(vehicleNo.equals(vehicle.getVehicleNo())) {
				vehicles.remove(vehicle);
				flag=true;
				break;
			}else {
				flag=false;
			}
		}
		
		return flag;
	}

	@Override
	public Vehicle modifyVehicle(String brandName,String VehicleType,String VehicleNo,int price) {

		Vehicle vh1=null;
		for (Vehicle vehicle : vehicles) {
			if(VehicleNo.equals(vehicle.getVehicleNo())) {
				vehicle.setBrandName(brandName);
				vehicle.setVehicleType(VehicleType);
				vehicle.setPrice(price);
				vh1=vehicle;
				break;
			}
		}
		
		
		return vh1;
	}

	


	@Override
	public List<Vehicle> getAllVehicles() {
		
		return vehicles;
	}


	@Override
	public Optional<Vehicle> getVehicle(String vehicleNo) {
		Vehicle veh = null;
		for (Vehicle vehicle : vehicles) {
			if(vehicleNo.equals(vehicle.getVehicleNo())) {
				veh=vehicle;
				break;
			}
		}
		
		return Optional.ofNullable(veh);
	}
}